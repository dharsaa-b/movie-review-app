Users can search for embedded videos of movie trailers on the Find Trailer page for the following movies:
- 12 Angry Men
- 2001: A Space Odyssey
- 3 Ninjas: High Noon at Mega Mountain
- Alien
- Aliens
- All About Eve
- All Quiet on the Western Front
- Amadeus
- American Beauty
- American History X

User must type in movie title spelled correctly (case-insenisitve). 
If one of the listed movie titles are searched, it's movie trailer will appear on the page and the textbox will clear.
Otherwise, nothing will appear on page and the textbox will clear.
