let config = {
  host    : 'ec2-18-216-101-119.us-east-2.compute.amazonaws.com',
  user    : 'dbhagude',
  password: 'MSCI245',
  database: 'dbhagude'
};
 
export default config;
