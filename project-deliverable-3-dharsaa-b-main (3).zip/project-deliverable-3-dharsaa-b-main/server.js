import mysql from 'mysql';
import config from './config.js';
import fetch from 'node-fetch';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
import response from 'express';
import { getRandomValues } from 'crypto';
import os from 'os';
console.log(os.hostname());


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 5000;
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));


app.use(express.static(path.join(__dirname, "client/build")));


app.post('/api/loadUserSettings', (req, res) => {

	let connection = mysql.createConnection(config);
	let userID = req.body.userID;

	let sql = `SELECT mode FROM user WHERE userID = ?`;
	console.log(sql);
	let data = [userID];
	console.log(data);

	connection.query(sql, data, (error, results, fields) => {
		if (error) {
			return console.error(error.message);
		}

		let string = JSON.stringify(results);
		//let obj = JSON.parse(string);
		res.send({ express: string });
	});
	connection.end();
});

app.post('/api/getMovies', (req, res) => {

	let connection = mysql.createConnection(config);
	//let movies = req.body.userID;

	let sql = `SELECT id, name, year, quality FROM movies`;
	console.log(sql);
	let data = [];
	console.log(data);

	connection.query(sql, data, (error, results, fields) => {
		if (error) {
			return console.error(error.message);
		}

		let string = JSON.stringify(results);
		//let obj = JSON.parse(string);
		res.send({ express: string });
	});
	connection.end();
});

app.post('/api/addReview', (req, res) => {

	let connection = mysql.createConnection(config);
	const {userID, movieID, reviewTitle, reviewContent, reviewScore} = req.body;

	let sql = `INSERT INTO Review (userID, movieID,reviewTitle, reviewContent, reviewScore) VALUES (?, ?, ?, ?, ?)`;
	let data = [userID, movieID,reviewTitle, reviewContent, reviewScore];

	connection.query(sql, data, (error, results, fields) => {
		if (error) {
			return console.error(error.message);
		}

		let string = JSON.stringify(results);
		//let obj = JSON.parse(string);
		res.send({ express: string });
	});
	connection.end();
});

app.post('/api/movieTrailer', (req, res) => {
	let connection = mysql.createConnection(config);
	let movieTitle = req.body.movieTitle;

	let sql = `Select trailer from movies where name = ?`;
	let data = [movieTitle];
	//console.log(sql);

	connection.query(sql, data, (error, results, fields) => {
		if (error) {
			return console.error(error.message);
		}
		//return res.json(results);
		let string = JSON.stringify(results)
        res.send({ express: string})

 

	});
	connection.end();
});

app.post('/api/search', (req, res) => {
	let connection = mysql.createConnection(config);
	let movieTitle = req.body.movieTitle;
	let actorName = req.body.actorName;
	let directorName = req.body.directorName;

	let sql2 = ' ';

	let sql1 = `select title, directorName, Group_Concat(DISTINCT RV.reviewContent) as review, avg(RV.reviewScore) as score
	from (
	
		select M.id, M.name as title, CONCAT (D.first_name, ' ', D.last_name) as directorName, CONCAT (A.first_name, ' ', A.last_name) as actorName
	
		from actors A, directors D, movies M, movies_directors MD, roles R
	
		where D.id = MD.director_id
	
		and MD.movie_id = M.id
	
		and M.id = R.movie_id
	
		and R.actor_id = A.id`;

	if (movieTitle) {
		sql2 = sql2 + `and M.name = "${movieTitle}"` + ' ';
		if (directorName) {
			sql2 = sql2 + `and CONCAT(D.first_name, ' ', D.last_name) = "${directorName}"` + ' ';
		}
		if (actorName) {
			sql2 = sql2 + `and CONCAT(A.first_name, ' ', A.last_name) = "${actorName}"`;
		}
	}
	else {
		if (directorName) {
			sql2 = sql2 + `and CONCAT(D.first_name, ' ', D.last_name) = "${directorName}"` + ' ';
		}
		if (actorName) {
			sql2 = sql2 + `and CONCAT(A.first_name, ' ', A.last_name) = "${actorName}"`;
		}
	}

	let sql3 = `) as M
	
	left join Review RV on M.id = RV.movieID
	
	group by title, directorName;`;

	let sql = sql1 + sql2 + sql3;

	connection.query(sql, movieTitle, (error, results, fields) => {
		if (error) {
			return console.error(error.message);
		}
		//return res.json(results);
		let string = JSON.stringify(results)
        res.send({ express: string})
	});
	connection.end();
	});
	
			

app.listen(port, () => console.log(`Listening on port ${port}`)); //for the dev version
//app.listen(port, '172.31.31.77'); //for the deployed version, specify the IP address of the server